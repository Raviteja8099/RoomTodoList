package com.example.roomtodolist;
@Entity(TableName="word_table")
public class Word {

}
